-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 07-12-2020 a las 11:11:19
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `bdmatisa`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `automovil`
-- 

CREATE TABLE `automovil` (
  `idautomovil` int(11) NOT NULL auto_increment,
  `chasis` varchar(20) default NULL,
  `num_motor` varchar(20) default NULL,
  `color` varchar(15) default NULL,
  `modelo` varchar(20) default NULL,
  `estado` varchar(15) default NULL,
  `precio_proforma` float default NULL,
  `foto` varchar(150) default NULL,
  `cilindrada` varchar(45) default NULL,
  `anio` varchar(6) default NULL,
  `traccion` varchar(10) default NULL,
  `idmarca` int(11) NOT NULL,
  `idtipo_veiculo` int(11) NOT NULL,
  `procedencia` varchar(45) default NULL,
  PRIMARY KEY  (`idautomovil`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `automovil`
-- 

INSERT INTO `automovil` VALUES (1, 'A12345', 'B12345', '', '2020', 'VENDIDO', 0, 'hyundai_elantra_2020_edit.jpg', '2000', 'ROJO', '4X4', 1, 3, 'CHINA');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cliente`
-- 

CREATE TABLE `cliente` (
  `idcliente` int(11) NOT NULL auto_increment,
  `ci` varchar(15) default NULL,
  `nombre` varchar(50) default NULL,
  `ocupacion` varchar(200) default NULL,
  `direccion` varchar(250) default NULL,
  `tel` varchar(15) default NULL,
  `cel` varchar(15) default NULL,
  PRIMARY KEY  (`idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

-- 
-- Volcar la base de datos para la tabla `cliente`
-- 

INSERT INTO `cliente` VALUES (1, '123456-OR', 'ARIAS ARANCIVIO', 'MUY FEO', 'MAS ALLA DE LAS ESTRELLAS', '123456', '126456');
INSERT INTO `cliente` VALUES (5, '8265223-OR', 'UBINA FERNANDEZ RAUL', 'COMERCIANTE', '', '', '72346737');
INSERT INTO `cliente` VALUES (6, '3089275-OR', 'LOPEZ ESCALIER OMAR DANTE', 'DOCENTE', '', '', '72498000');
INSERT INTO `cliente` VALUES (7, '5062517-OR', 'CARRIZO VILLAM', '', '', '', '68312439');
INSERT INTO `cliente` VALUES (8, '3539626-OR', 'CONDORI COLQUE RAUL', 'INGENIERO AGRONOMO', '', '', '71857675');
INSERT INTO `cliente` VALUES (9, '30835329-OR', 'CALDERO FERNANDEZ LOURDES', 'PROFESORA', '', '', '72461933');
INSERT INTO `cliente` VALUES (10, '5755844-OR', 'VILTE ARANCIBIA  ZULMA ', 'RENTISTA Y AMA DE CASA', 'URBANIZACIÃ“N JANKO COTA SORA MAZNO 47 LOTE= 3', '', '61665138');
INSERT INTO `cliente` VALUES (11, '4075499-OR', 'OJEDA CHAMBI CRISTOBAL', 'ASALARIADO/MINERO', 'PRONG. PARAGUAY NÂº 57 SAN SILVESTRE Y SAN JUNIOR ', '', '71185024');
INSERT INTO `cliente` VALUES (12, '7278257-OR', 'CANAVIRI  ALBINO', 'REPOSTERO INDEPENDIENTE', 'SIN DIRECCION ', '', '75421105');
INSERT INTO `cliente` VALUES (13, '7278257-OR', 'CANAVIRI  ALBINO', 'REPOSTERO INDEPENDIENTE', 'SIN DIRECCION ', '', '75421105');
INSERT INTO `cliente` VALUES (14, '7278257-OR', 'CANAVIRI  ALBINO', 'REPOSTERO INDEPENDIENTE', 'SIN DIRECCION ', '', '75421105');
INSERT INTO `cliente` VALUES (15, '7413465-OR', 'CHOQUE CAPURATA', 'ASALARIADO/MINERO', 'FINAL POTOSI Y JUNIN', '', '68296077');
INSERT INTO `cliente` VALUES (16, '3504967-OR', 'FLORES  DELIA', 'EMPLEADA ASALARIADA MINA SAN CRISTOBAL', 'S/D', '', '72396824');
INSERT INTO `cliente` VALUES (17, '5770126-OR', 'CATARI  JUAN GABRIEL ', 'ASALARIADO', 'S/DIRECCIÃ“N ', '', '76158443');
INSERT INTO `cliente` VALUES (18, '5765932-OR', 'VEDIA MENDOZA MARTINIANO', 'TRANSPORTISTA/MUSICO', 'SIN DIRECCIÃ“N ', '', '73316686');
INSERT INTO `cliente` VALUES (19, '00-OR', 'CONDORI CONDORI OBISPO', 'TRANSPORTISTA', 'C.D.', '74318747', '74318747');
INSERT INTO `cliente` VALUES (20, '5538093-OR', 'QUINTANILLA  GUSTAVO', 'ASALARIADO', 'S / DIRECCIÃ“N ', '', '77147867');
INSERT INTO `cliente` VALUES (21, '00-OR', 'OROZCO ITAMARI MARCIAL', 'COMERCIANTE', 'C.D.', '74134535', '74134535');
INSERT INTO `cliente` VALUES (22, '6992004-LP', 'MAMANI COLQUE ENRIQUE', 'PROFESOR', 'PSJE. FERROVIARIO NÂº 424 ENTRE AV. PETROLERA', '', '63872929');
INSERT INTO `cliente` VALUES (23, '12551597-PT', 'MELCHOR PORCO  HECTOR', 'AUX. ENFERMERÃA', 'AV. BUENOS AIRES S/N Y AYACUCHO', '', '71510652');
INSERT INTO `cliente` VALUES (24, '00-OR', 'CONDORI COLQUE RAUL', 'AGRONOMO', 'S.D.', '71857675', '71857675');
INSERT INTO `cliente` VALUES (25, '00-OR', 'BENAVIDES SERGIO', '', 'S.D.', '67528473', '67528473');
INSERT INTO `cliente` VALUES (26, '00-OR', 'BENAVIDES SERGIO', '', 'S.D.', '67528473', '67528473');
INSERT INTO `cliente` VALUES (27, '5069133-OR', 'FERNANDES JUAN MANUEL', 'TRANSPORTISTA', 'S.D.', '78608681', '78608681');
INSERT INTO `cliente` VALUES (28, '5069133-OR', 'FERNANDES JUAN MANUEL', 'TRANSPORTISTA', 'S.D.', '78608681', '78608681');
INSERT INTO `cliente` VALUES (29, '3975335-PT', 'CARRIZO ELISEO', 'TRANSPORTISTA', 'S.D.', '72457339', '72457337');
INSERT INTO `cliente` VALUES (30, '3975335-PT', 'CARRIZO ELISEO', 'TRANSPORTISTA', 'S.D.', '72457339', '72457337');
INSERT INTO `cliente` VALUES (31, '3975335-PT', 'CARRIZO ELISEO', 'TRANSPORTISTA', 'S.D.', '72457339', '72457337');
INSERT INTO `cliente` VALUES (32, '4036631-OR', 'OROZCO ITAMARI RICARDO', 'TRANSPORTISTA', 'S.D.', '71188114', '71188114');
INSERT INTO `cliente` VALUES (33, '4036631-OR', 'OROZCO ITAMARI RICARDO', 'TRANSPORTISTA', 'S.D.', '71188114', '71188114');
INSERT INTO `cliente` VALUES (34, '4036631-OR', 'OROZCO ITAMARI RICARDO', 'TRANSPORTISTA', 'S.D.', '71188114', '71188114');
INSERT INTO `cliente` VALUES (35, '4036631-OR', 'OROZCO ITAMARI RICARDO', 'TRANSPORTISTA', 'S.D.', '71188114', '71188114');
INSERT INTO `cliente` VALUES (36, '5736726-OR', 'OROZCO ITAMARI BERNADO', 'TRANSPORTISTA', 'S.D.', '72456185', '72456185');
INSERT INTO `cliente` VALUES (37, '5736726-OR', 'OROZCO ITAMARI BERNADO', 'TRANSPORTISTA', 'S.D.', '72456185', '72456185');
INSERT INTO `cliente` VALUES (38, '3540698-OR', 'BELTRAN YAVE WILFREDO MARCELO', 'TRANSPORTISTA', 'S.D.', '68630968', '68630968');
INSERT INTO `cliente` VALUES (39, '3540698-OR', 'BELTRAN YAVE WILFREDO MARCELO', 'TRANSPORTISTA', 'S.D.', '68630968', '68630968');
INSERT INTO `cliente` VALUES (40, '3540698-OR', 'BELTRAN YAVE WILFREDO MARCELO', 'TRANSPORTISTA', 'S.D.', '68630968', '68630968');
INSERT INTO `cliente` VALUES (41, '3540698-OR', 'BELTRAN YAVE WILFREDO MARCELO', 'TRANSPORTISTA', 'S.D.', '68630968', '68630968');
INSERT INTO `cliente` VALUES (42, '4279430-OR', 'HUANCA VICENTE', 'SONBRERERO', 'S.D.', '72349829', '72346829');
INSERT INTO `cliente` VALUES (43, '4279430-OR', 'HUANCA VICENTE', 'SONBRERERO', 'S.D.', '72349829', '72346829');
INSERT INTO `cliente` VALUES (44, '00-OR', 'RODRIGUEZ AMILKAR', 'IMPORTADOR', 'S.D.', '72335879', '72335879');
INSERT INTO `cliente` VALUES (45, '00-OR', 'RODRIGUEZ AMILKAR', 'IMPORTADOR', 'S.D.', '72335879', '72335879');
INSERT INTO `cliente` VALUES (46, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (47, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (48, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (49, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (50, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (51, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (52, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (53, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (54, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (55, '000-OR', 'YAVE MAMANI ARIEL', 'COMERCIANTE', 'S.D.', '75425765', '75425765');
INSERT INTO `cliente` VALUES (56, '3102005-OR', 'BLANCO PAILO FELIZA', 'ASALARIADA', 'S.D.', '77158568', '77158568');
INSERT INTO `cliente` VALUES (57, '7289832-OR', 'MAMANI VARGAS MARIO', 'ASALARIADO', 'S.D.', '72223174', '72223174');
INSERT INTO `cliente` VALUES (58, '7269510-OR', 'VASQUEZ ORTEGA MIGUEL CANCIO', 'CHOFER', 'URBANIZACION JUAN PABLO NRO 11 ZONA ESTE ', '5288208', '69527659');
INSERT INTO `cliente` VALUES (59, '4586727-OR', 'TURCO KEMEL', 'COMERCIANTE LIBRERIA', '6 DE OCTUBRE JUNIN AYACUCHO ', '', '70415308');
INSERT INTO `cliente` VALUES (60, '5774312-OR', 'CONDORI SANDRO', 'COSTURA', 'BARRIO KANTUTA ', '', '72337899');
INSERT INTO `cliente` VALUES (61, '739944-OR', 'CUSI  MODESTO ', 'ALBANIL', 'S/D', '', '73845792');
INSERT INTO `cliente` VALUES (62, '3528578-OR', 'TITO EDSON', 'URBANIZACIÃ“N AURORA', 'ORQUESTA', '', '72462748');
INSERT INTO `cliente` VALUES (63, '8547450-PT', 'QUISPE  LUIS ANGEL', 'CHOFER TIENE SU RADIO TAXIS', 'URBANIZACION MILENIO MZO H 6 LOTE 24', '', '72444233');
INSERT INTO `cliente` VALUES (64, '2725735-OR', 'ROSALES SILES JULIAN', 'SERIGRAFIA', 'TEJERINA ENTRE MURGUIA Y ALDANA ', '', '77157695');
INSERT INTO `cliente` VALUES (65, '5743252-OR', 'CANAVIRI RIOS FERNANDO', 'TRANSPORTISTA', 'S/N', '', '73315387');
INSERT INTO `cliente` VALUES (66, '7274334-OR', 'CHAMBI MIRIAN', 'COMERCIANTE', 'FINAL SUCRE ', '', '77147651');
INSERT INTO `cliente` VALUES (67, '7280867-OR', 'CHAMBI WILFREDO', 'ASALARIADO DEL MAGISTERIO', 'FINAL VELASCO', '', '72348508');
INSERT INTO `cliente` VALUES (68, '7280867-OR', 'CHAMBI WILFREDO', 'ASALARIADO DEL MAGISTERIO', 'FINAL VELASCO', '', '72348508');
INSERT INTO `cliente` VALUES (69, '7873932-CB', 'CABRERA ROMERO OSCAR JAVIER', 'ESTUDIANTE', 'URB. PEDRO FERRARI', '', '61616125');
INSERT INTO `cliente` VALUES (70, '7274334-OR', 'CHAMBI MARIAN', 'COMERCIANTE', 'FINAL SUCRE', '', '77147651');
INSERT INTO `cliente` VALUES (71, '7280867-OR', 'CHAMBI WILFREDO', 'FINAL VELASCO', 'ASALARIADO', '', '72348508');
INSERT INTO `cliente` VALUES (72, '7280867-OR', 'CHAMBI WILFREDO', 'FINAL VELASCO', 'ASALARIADO', '', '72348508');
INSERT INTO `cliente` VALUES (73, '77158175-OR', 'CORDOVA ENRIQUE', 'ASALARIADO', 'SOCAVON', '', '77158175');
INSERT INTO `cliente` VALUES (74, '3513272-OR', 'GABRIEL HUANCA  LUCIANO', 'CHOFER', 'ARCE NÂ·115 TARAPACA', '', '73834348');
INSERT INTO `cliente` VALUES (75, '2721070-OR', 'MICHEL MARTINEZ EDWIN', 'ASALARIADO', 'FIANL AMERICA ACHA', '', '68359791');
INSERT INTO `cliente` VALUES (76, '3059086-OR', 'MIRANDA  SANDRA ', 'ODONTOLOGA', 'CBBA 6 DE OCTUBRE ', '', '73831742');
INSERT INTO `cliente` VALUES (77, '5720042-OR', 'MORALES  JAIME', 'ASALARIADO', 'HUANUNI', '', '71853937');
INSERT INTO `cliente` VALUES (78, '4023709-OR', 'ORDOÃ‘ES ARIEL', 'CHOFER', 'PAGADOR ENTRE 12 DE OCTUBRE ', '', '63106630');
INSERT INTO `cliente` VALUES (79, '4075287-OR', 'MAMANI GROVER', 'ASALARIADO', 'PROVINCIA POOPO', '', '72347961');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cuenta_por_pagar`
-- 

CREATE TABLE `cuenta_por_pagar` (
  `idcuenta_por_pagar` int(11) NOT NULL auto_increment,
  `detalle` varchar(150) default NULL,
  `num_recibo` varchar(15) default NULL,
  `fecha_a_pagar` date default NULL,
  `monto` float default NULL,
  `garantia` varchar(150) default NULL,
  `fecha_registro` date default NULL,
  `tipo_cambio` float default NULL,
  `num_contrato` varchar(15) default NULL,
  `idempleado` int(11) NOT NULL,
  PRIMARY KEY  (`idcuenta_por_pagar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `cuenta_por_pagar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `desembolso`
-- 

CREATE TABLE `desembolso` (
  `iddesembolso` int(11) NOT NULL auto_increment,
  `monto` float default NULL,
  `tipo_cambio` float default NULL,
  `num_recivo` varchar(25) default NULL,
  `fecha` date default NULL,
  `idventas` int(11) NOT NULL,
  PRIMARY KEY  (`iddesembolso`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `desembolso`
-- 

INSERT INTO `desembolso` VALUES (1, 15000, 6.97, 'NOL-561', '2020-12-07', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `detalle_transac`
-- 

CREATE TABLE `detalle_transac` (
  `iddetalle_transac` int(11) NOT NULL auto_increment,
  `detalle` varchar(150) default NULL,
  PRIMARY KEY  (`iddetalle_transac`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `detalle_transac`
-- 

INSERT INTO `detalle_transac` VALUES (1, 'ESCRITORIO');
INSERT INTO `detalle_transac` VALUES (2, 'COMPRA INSUMOS DE DESAYUNO');
INSERT INTO `detalle_transac` VALUES (3, 'MERCANTIL SANTA CRUZ');
INSERT INTO `detalle_transac` VALUES (4, 'IMPRESORA');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `documento`
-- 

CREATE TABLE `documento` (
  `iddocumento` int(11) NOT NULL auto_increment,
  `descripcion` varchar(100) default NULL,
  `foto` varchar(150) default NULL,
  `ventas_idventas` int(11) NOT NULL,
  PRIMARY KEY  (`iddocumento`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `documento`
-- 

INSERT INTO `documento` VALUES (1, 'BOLETA DE ENTREGA', 'descarga.jfif', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `empleado`
-- 

CREATE TABLE `empleado` (
  `idempleado` int(11) NOT NULL auto_increment,
  `ci` varchar(15) default NULL,
  `nombre` varchar(50) default NULL,
  `apellido` varchar(50) default NULL,
  `telefono` varchar(15) default NULL,
  `celular` varchar(15) default NULL,
  `direccion` varchar(250) default NULL,
  `estado` varchar(15) default NULL,
  PRIMARY KEY  (`idempleado`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `empleado`
-- 

INSERT INTO `empleado` VALUES (1, '12345678OR', 'ADMIN', 'ADMIN', NULL, NULL, NULL, 'ACTIVO');
INSERT INTO `empleado` VALUES (2, '5560638-PT', 'LUIS EDGAR', 'PEREZ PACO', '', '68325416', 'URB. SAN AGUSTIN MZ.4 LOTE 5', 'ACTIVO');
INSERT INTO `empleado` VALUES (3, '5773714-OR', 'GLADIZ RAQUEL ', 'FERRUFINO PACHECO', '5232257', '75710716', 'URBANIZACION AURORA UV 5 K 3', 'ACTIVO');
INSERT INTO `empleado` VALUES (4, '7334505-OR', 'MONICA', 'GOMEZ COSME', '', '67211095', 'CALAMA N95 ENTRE ESPAÑA Y PERU', 'ACTIVO');
INSERT INTO `empleado` VALUES (5, '4931954-LP', 'RUDY CESAR', 'SANEZ CLEMENTE', '5212992', '70415175', 'CALLE PASTOR SAINZ N2', 'ACTIVO');
INSERT INTO `empleado` VALUES (6, '5733142-OR', 'FABIOLA ISABEL', 'VIDEA QUIROGA', '5212992', '70417037', 'CALLE PASTOR SAIZ NUMERO 2', 'ACTIVO');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `entidad_bancaria`
-- 

CREATE TABLE `entidad_bancaria` (
  `identidad_bancaria` int(11) NOT NULL auto_increment,
  `descripcion` varchar(150) default NULL,
  PRIMARY KEY  (`identidad_bancaria`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `entidad_bancaria`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `marca`
-- 

CREATE TABLE `marca` (
  `idmarca` int(11) NOT NULL auto_increment,
  `descripcion` varchar(45) default NULL,
  PRIMARY KEY  (`idmarca`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

-- 
-- Volcar la base de datos para la tabla `marca`
-- 

INSERT INTO `marca` VALUES (1, 'KING LONG T.S.A.');
INSERT INTO `marca` VALUES (2, 'KIN LONG BUFALO');
INSERT INTO `marca` VALUES (3, 'JIN CHEN T.S.A.');
INSERT INTO `marca` VALUES (5, 'GOLDEN DRAGON T.S.A');
INSERT INTO `marca` VALUES (6, 'GOLDEN DRAGON T.S.A');
INSERT INTO `marca` VALUES (7, 'GOLDEN DRAGON T.S.A');
INSERT INTO `marca` VALUES (8, 'GOLDEN DRAGON T.S.A');
INSERT INTO `marca` VALUES (9, 'GOLDEN DRAGON T.S.A');
INSERT INTO `marca` VALUES (10, 'GOLDEN DRAGON T.A.');
INSERT INTO `marca` VALUES (11, 'JIN CHEN CUADRADO');
INSERT INTO `marca` VALUES (12, 'GOLDEN DRAGON BUFALO');
INSERT INTO `marca` VALUES (13, 'FOTON');
INSERT INTO `marca` VALUES (14, 'HIGER');
INSERT INTO `marca` VALUES (15, 'KEYTON');
INSERT INTO `marca` VALUES (16, 'FAW');
INSERT INTO `marca` VALUES (17, 'JIN BEI');
INSERT INTO `marca` VALUES (18, 'T-KING');
INSERT INTO `marca` VALUES (19, 'KING LANG');
INSERT INTO `marca` VALUES (20, 'KAWEI');
INSERT INTO `marca` VALUES (21, 'BYD');
INSERT INTO `marca` VALUES (22, 'GLORY');
INSERT INTO `marca` VALUES (23, 'CHERY');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `otrosgastos`
-- 

CREATE TABLE `otrosgastos` (
  `idotrosgastos` int(11) NOT NULL auto_increment,
  `descripcion` varchar(50) default NULL,
  `costo` float default NULL,
  `tipo_cambio` float default NULL,
  `idventas` int(11) NOT NULL,
  PRIMARY KEY  (`idotrosgastos`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `otrosgastos`
-- 

INSERT INTO `otrosgastos` VALUES (1, 'VIDRIOS POLARIZADOS', 200, 6.97, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pago`
-- 

CREATE TABLE `pago` (
  `idpago` int(11) NOT NULL auto_increment,
  `fecha` date default NULL,
  `nomto` float default NULL,
  `detalle` varchar(250) default NULL,
  `tipo_cambio` float default NULL,
  `idplan_pagos` int(11) NOT NULL,
  PRIMARY KEY  (`idpago`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `pago`
-- 

INSERT INTO `pago` VALUES (1, '2020-12-07', 2000, '---', 6.97, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `plan_pagos`
-- 

CREATE TABLE `plan_pagos` (
  `idplan_pagos` int(11) NOT NULL auto_increment,
  `fecha` date default NULL,
  `nomto` float default NULL,
  `tipo_cambio` float default NULL,
  `cantidad_meses` int(11) default NULL,
  `interes` float default NULL,
  `idventas` int(11) NOT NULL,
  PRIMARY KEY  (`idplan_pagos`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `plan_pagos`
-- 

INSERT INTO `plan_pagos` VALUES (1, '2020-12-07', 2000, 6.97, 15, 30, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `saldo`
-- 

CREATE TABLE `saldo` (
  `idsaldo` int(11) NOT NULL auto_increment,
  `detalle` float default NULL,
  PRIMARY KEY  (`idsaldo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `saldo`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `saldo_banco`
-- 

CREATE TABLE `saldo_banco` (
  `idsaldo_banco` int(11) NOT NULL auto_increment,
  `detalle` float default NULL,
  PRIMARY KEY  (`idsaldo_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `saldo_banco`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_veiculo`
-- 

CREATE TABLE `tipo_veiculo` (
  `idtipo_veiculo` int(11) NOT NULL auto_increment,
  `descripcion` varchar(50) default NULL,
  PRIMARY KEY  (`idtipo_veiculo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `tipo_veiculo`
-- 

INSERT INTO `tipo_veiculo` VALUES (1, 'MINIBUS');
INSERT INTO `tipo_veiculo` VALUES (2, 'MINIVAN');
INSERT INTO `tipo_veiculo` VALUES (3, 'VAGONETA');
INSERT INTO `tipo_veiculo` VALUES (4, 'CAMIONETA');
INSERT INTO `tipo_veiculo` VALUES (5, 'BUS');
INSERT INTO `tipo_veiculo` VALUES (6, 'VEHICULO');
INSERT INTO `tipo_veiculo` VALUES (7, 'COMPACTO');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `transaccion`
-- 

CREATE TABLE `transaccion` (
  `idtransaccion` int(11) NOT NULL auto_increment,
  `num_recivo` varchar(45) default NULL,
  `fecha` date default NULL,
  `monto` float default NULL,
  `tipocambio` float default NULL,
  `tipo` varchar(25) default NULL,
  `iddetalle_transac` int(11) NOT NULL,
  `idempleado` int(11) NOT NULL,
  PRIMARY KEY  (`idtransaccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `transaccion`
-- 

INSERT INTO `transaccion` VALUES (1, '5255', '2020-11-28', 300, 6.97, 'INGRESO', 1, 1);
INSERT INTO `transaccion` VALUES (2, '', '2020-11-28', 50, 6.97, 'EGRESO', 2, 1);
INSERT INTO `transaccion` VALUES (3, 'NOL-56156', '2020-12-07', 5000, 6.97, 'INGRESO', 3, 1);
INSERT INTO `transaccion` VALUES (4, 'NOL-561586', '2020-12-07', 1500, 6.97, 'EGRESO', 1, 1);
INSERT INTO `transaccion` VALUES (5, 'NOL-561586', '2020-12-07', 800, 6.97, 'EGRESO', 4, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `transaccion_bancos`
-- 

CREATE TABLE `transaccion_bancos` (
  `idtransaccion_bancos` int(11) NOT NULL auto_increment,
  `detalle` varchar(200) default NULL,
  `fecha` date default NULL,
  `monto` float default NULL,
  `tipocambio` float default NULL,
  `tipo` varchar(25) default NULL,
  `idempleado` int(11) NOT NULL,
  `identidad_bancaria` int(11) NOT NULL,
  PRIMARY KEY  (`idtransaccion_bancos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `transaccion_bancos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario`
-- 

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL auto_increment,
  `usuario` varchar(45) default NULL,
  `contrasenia` varchar(45) default NULL,
  `tipo_empleado` varchar(45) default NULL,
  `idempleado` int(11) NOT NULL,
  PRIMARY KEY  (`idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `usuario`
-- 

INSERT INTO `usuario` VALUES (1, 'usuario', '123456', 'ADMINISTRADOR', 1);
INSERT INTO `usuario` VALUES (2, 'lperez', '5560638lcm', 'EJECUTIVO DE VENTAS', 2);
INSERT INTO `usuario` VALUES (3, 'Rferrufino', 'vale1234', 'EJECUTIVO DE VENTAS', 3);
INSERT INTO `usuario` VALUES (4, 'Mgomez', 'laura1998', 'EJECUTIVO DE VENTAS', 4);
INSERT INTO `usuario` VALUES (5, 'rsanez', 'Matias13*', 'ADMINISTRADOR', 5);
INSERT INTO `usuario` VALUES (6, 'Fvidea', 'Isabela24*', 'ADMINISTRADOR', 6);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ventas`
-- 

CREATE TABLE `ventas` (
  `idventas` int(11) NOT NULL auto_increment,
  `cod_cli` varchar(25) default NULL,
  `precio_venta` float default NULL,
  `fecha_venta` date default NULL,
  `tipo_venta` varchar(10) default NULL,
  `estado` varchar(15) default NULL,
  `saldo` float default NULL,
  `antisipo` float default NULL,
  `garantia` varchar(250) default NULL,
  `entidad_financiera` varchar(150) default NULL,
  `tipo_de_cambio` float default NULL,
  `idempleado` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `idautomovil` int(11) NOT NULL,
  PRIMARY KEY  (`idventas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `ventas`
-- 

INSERT INTO `ventas` VALUES (1, 'AD-123', 75000, '2020-12-07', 'CREDITO', 'INCOMPLETO', 66000, 7000, 'DOC. ARANCIBIA ', 'MERCANTIL SANTA CRUZ', 6.98, 1, 6, 1);
